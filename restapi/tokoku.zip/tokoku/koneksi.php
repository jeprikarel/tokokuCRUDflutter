<?php

$connect = new mysqli("localhost","root","","tokoku");

if($connect){
	 
}else{
	echo "Gagal, periksa ip atau firewall";
	exit();
}