<?php

	include 'koneksi.php';
	
	$id = $_POST['id'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$level = $_POST['level'];

	
	$connect->query("UPDATE user SET username='".$username."', password='".$password."', level='".$level."' WHERE id=". $id);

?>