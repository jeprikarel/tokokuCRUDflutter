<?php

    include 'koneksi.php';

    $username = $_POST['username'];
    $password = $_POST['password'];

    $login2=$connect->query("SELECT * FROM user WHERE username='".$username."' and password='".$password."'");

    $hasil=array();

    while($ekstrakData=$login2->fetch_assoc()){
        $hasil[]=$ekstrakData;
    } 

    echo json_encode($hasil);

    ?>