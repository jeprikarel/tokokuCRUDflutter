# PHP-REST-API
PHP REST API FILE for Flutter CRUD Project

Flutter CRUD phpMyAdmin Project : https://github.com/idrcorner/Flutter-CRUD-phpMyAdmin
